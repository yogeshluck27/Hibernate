34 video lessons on hibernate - I've modified the source code a little,
because I create a package for every argument, instead of adding and
deleting code from the same objects, like is done in the tutorial.
Also I'm using Maven to configure the dependencies.


http://javabrains.koushik.org/p/hibernate.html
